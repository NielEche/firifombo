
<img class="w-62 p-6 mt-2" style="padding:50px;" src="https://res.cloudinary.com/nieleche/image/upload/v1703082403/Screenshot_2023-12-20_at_15.03.00_k8ztg9.png" alt="firi!">

<div class="w-full absolute" style="bottom:0px; padding:20px;">
<span class="relative LemonJelly text-xl px-12 center flex align-center" style="line-height: 0.8;">Dynamic Babe at the intersection of art, culture, media and enjoyment.</span>
</div>
