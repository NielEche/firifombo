<div class="flex justify-between p-6 pb-0 text-black theunseen">
    <a href="#" class="text-5xl px-6">Photography</a>
</div>
<div  class="flex justify-end px-6 text-black theunseen">
    <img class="w-40" src="https://res.cloudinary.com/nieleche/image/upload/v1695211320/photo_cds2jw.png" alt="">
</div>

<div class="flex justify-around p-6 pb-0 text-black theunseen">
    <img class="w-40" src="https://res.cloudinary.com/nieleche/image/upload/v1695212692/write_uzbr7s.png" alt="">
    <a href="#" class="text-4xl">Writing</a>
</div>


<div class=" p-6 pb-0 text-black text-left theunseen">
    <a href="#" class="text-5xl px-4">Audio</a>
    <img class="w-44 absolute bottom-0 right-6" src="https://res.cloudinary.com/nieleche/image/upload/v1695270508/audio_wbhwkb.png" alt="">
</div>