
<center>
        <div class="">
            <div class="mainAppsUpp">
                <div class="flex" style="justify-content: center;">
                    <a href="https://www.instagram.com/firifombo/?hl=en"  target="_blank">
                        <img src="https://res.cloudinary.com/nieleche/image/upload/v1702485430/instagram_gq2zza.png" alt="">
                        <p style="font-size:10px;" class="text-white">Instagram</p>
                    </a>

                    <a href="https://twitter.com/FiriFombo" target="_blank">
                        <img src="https://res.cloudinary.com/nieleche/image/upload/v1702494310/twitter_bj7d22.png" alt="">
                        <p style="font-size:10px;" class="text-white">X</p>
                    </a>
                    
                    <a href="https://www.pinterest.com/firifombo/"  target="_blank">
                        <img src="https://res.cloudinary.com/nieleche/image/upload/v1702494896/pinterest_z7ujoe.png" alt=""> 
                        <p style="font-size:10px;" class="text-white">Pinterest</p>
                    </a>

                    <a href="https://www.google.com/maps/place/Canada/@48.7795745,-135.6523172,3z/data=!3m1!4b1!4m6!3m5!1s0x4b0d03d337cc6ad9:0x9968b72aa2438fa5!8m2!3d56.130366!4d-106.346771!16zL20vMGQwNjBn?entry=ttu"  target="_blank">
                        <img src="https://res.cloudinary.com/nieleche/image/upload/v1702496423/map_uewz27.png" alt=""> 
                        <p style="font-size:10px;" class="text-white">Address</p>
                    </a>

                </div>

                <div class="flex" style="margin-left: 25px; margin-top:10px;">
                    <a href="https://www.threads.net/@firifombo"  target="_blank">
                        <img src="https://res.cloudinary.com/nieleche/image/upload/v1702496931/threads_r5fuem.png" alt=""> 
                        <p style="font-size:10px;" class="text-white">Threads</p>
                    </a>
                    <a href="#">
                        <img src="https://res.cloudinary.com/nieleche/image/upload/v1702498245/store_bevsta.png" alt=""> 
                        <p style="font-size:10px;" class="text-white">Store</p>
                    </a>
                </div>
            </div>
           
            
            <div class="mainApps flex">
                <a href="tel:+16479047225">
                    <img src="https://res.cloudinary.com/nieleche/image/upload/v1702479524/phoneA_fqecsn.png" alt="">
                </a>

                <a href="https://open.spotify.com/user/31gaqp5mjrls77omsdyhbsuk46ji" target="_blank">
                    <img src="https://res.cloudinary.com/nieleche/image/upload/v1702479524/spotifyA_ssjsh4.png" alt="">
                </a>
                
                <a  href="mailto:tamunoibifirifombo@gmail.com">
                    <img src="https://res.cloudinary.com/nieleche/image/upload/v1702479524/messageA_grmtq1.png" alt=""> 
                </a>
            </div>
            <img src="https://res.cloudinary.com/nieleche/image/upload/v1702362258/yellowApp34firi_rdlokv_avw8lp.png" alt="">
        </div>
        
    </center>

    <style>
        .audioTitle {
            font-size:25px;
            color:black;
            margin-top:10px;
        }   
    
        .mainApps {
            position: absolute;
            bottom:0;
            width:100%;
            height:60px;
            margin-bottom:17px;
            justify-content: center;
        }

        .mainAppsUpp {
            position: absolute;
            top:0;
            width:100%;
            height:60px;
            margin-top:17px;
            justify-content: center;
        }

        .mainAppsUpp img{
            padding:0px 10px;
            height:60px;
        }
        .mainAppsUpp p{
            font-weight:600;
        }

        .mainApps img{
            padding:0px 10px;
            height:60px;
        }
    </style>
<?php /**PATH /Users/nieleche/Documents/CODEBASE/firifombo/resources/views/pages/contact.blade.php ENDPATH**/ ?>