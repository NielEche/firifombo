<div class="">
    <div class="w-full px-4" >
        <span class="text-center text-6xl text-black text-bold UNDERTOWNPERSONALUSE">HELLO I'M</span>
    </div>
    <div class="flex px-4" >
        <div>
            <img src="https://res.cloudinary.com/nieleche/image/upload/v1695197504/ybg_ycl7rj_d5coww.png" style="width:195px; height: 230px;" alt="">
        </div>
        <div>
            <img src="https://res.cloudinary.com/nieleche/image/upload/v1695199878/stickynotefiri_yvfpco.png" style="width:130px; height: 130px;" class="mt-10"  alt="">
        </div>
    </div>
    <div class="flex  px-4">
     <div class="">
            <img src="https://res.cloudinary.com/nieleche/image/upload/v1695199147/round_klisio_tztlsq.png" class="w-36" alt="">
        </div>
        <div class="">
            <img src="https://res.cloudinary.com/nieleche/image/upload/v1695194940/white_yx1ydw_kyfugq.png" style="width:50%; position:absolute; bottom:50px; right:10px;" alt="">
        </div>
    </div>
    <div class="w-full absolute" style="bottom:0px;">
        <span class="text-center text-5xl text-black text-bold UNDERTOWNPERSONALUSE">FIRI FOMBO</span>
    </div>
    
</div><?php /**PATH /Users/nieleche/Documents/CODEBASE/firifombo/resources/views/pages/home.blade.php ENDPATH**/ ?>