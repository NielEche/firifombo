<div class=" p-6 pb-0 text-black text-left theunseen">
    <img class="w-10 absolute bottom-0 " src="https://res.cloudinary.com/nieleche/image/upload/v1697276362/chair_ijojeb.png" alt="">
</div><?php /**PATH /Users/nieleche/Documents/CODEBASE/firifombo/resources/views/pages/about2.blade.php ENDPATH**/ ?>