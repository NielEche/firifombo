
    <img class="w-78 p-6 mt-10" src="https://res.cloudinary.com/nieleche/image/upload/v1695183147/Screenshot_2023-09-20_at_04.54.05_k5vql6.png" alt="firi!">
    <span class="relative LemonJelly text-6xl">Firi Fombo</span>

    <div class="w-full absolute" style="bottom:0px; padding:20px;">
    <span class="relative LemonJelly text-xl px-12 center flex align-center" style="line-height: 0.8;">Dynamic Babe at the intersection of art, culture, media and enjoyment.</span>
    </div>
<?php /**PATH /Users/nieleche/Documents/CODEBASE/firifombo/resources/views/pages/cover.blade.php ENDPATH**/ ?>